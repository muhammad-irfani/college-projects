const fs = require('fs');
const path = './database';
if (!fs.existsSync(path)) {
  fs.mkdirSync(path);
}
const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./database/houses.db');

db.serialize(() => {
  db.run(`DROP TABLE IF EXISTS houses`);
  db.run(`CREATE TABLE houses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    price INTEGER NOT NULL,
    bedrooms INTEGER,
    bathrooms INTEGER,
    type TEXT,
    details TEXT
  )`);

  const stmt = db.prepare("INSERT INTO houses (title, price, bedrooms, bathrooms, type, details) VALUES (?, ?, ?, ?, ?, ?)");

  const listings = [
    ["Luxury 8BR Mansion", 2500000, 8, 5, "Mansion", "Spacious closets, grand living room, pool, large backyard"],
    ["Modern 6BR Smart Home", 1800000, 6, 4, "Single Family", "Walk-in closets, open-plan living room, garden, patio"],
    ["Colonial 5BR Family House", 1100000, 5, 3, "Single Family", "Ample storage, family room, deck, backyard"],
    ["Affordable 3BR Starter", 320000, 3, 2, "Condo", "Cozy space, modern kitchen, small backyard"],
    ["Renovated 4BR Ranch", 525000, 4, 2, "Ranch", "Updated interiors, closet organizers, sunroom, garden"],
    ["Cozy 2BR Bungalow", 275000, 2, 1, "Bungalow", "Compact home, open living area, backyard with shed"],
    ["Spacious 7BR Estate", 1995000, 7, 5, "Estate", "Luxury closets, multiple lounges, large backyard"],
    ["Urban 1BR Apartment", 199000, 1, 1, "Apartment", "Efficient layout, closet space, city-view balcony"]
  ];

    const moreListings = [
  ('Charming 3BR Townhouse', 450000, 3, 2, 'Townhouse', 'Spacious kitchen, walk-in closets, backyard patio'),
  ('Luxury 4BR Penthouse', 1300000, 4, 3, 'Apartment', 'Skyline views, rooftop access, modern interior'),
  ('Economical 2BR Flat', 210000, 2, 1, 'Apartment', 'Compact space, modern amenities, city living'),
  ('Modern 5BR Suburban Home', 850000, 5, 3, 'Single Family', 'Finished basement, 2-car garage, garden space'),
  ('Rustic 4BR Farmhouse', 650000, 4, 2, 'Ranch', 'Farm feel, barn, open backyard, classic charm'),
  ('Affordable 1BR Condo', 190000, 1, 1, 'Condo', 'Efficient layout, storage closet, secure building'),
  ('Elegant 6BR Estate', 2200000, 6, 5, 'Estate', 'Private lake access, luxury features, massive garden'),
  ('Urban 3BR Duplex', 480000, 3, 2, 'Condo', 'Shared backyard, modern layout, downtown location'),
  ('Large 7BR Mansion', 2700000, 7, 5, 'Mansion', 'Luxury everything, massive rooms, pool & spa'),
  ('Compact 1BR Bungalow', 180000, 1, 1, 'Bungalow', 'Cozy and efficient, perfect for singles or couples')
  ];
  moreListings.forEach(l => stmt.run(...l));

  listings.forEach(l => stmt.run(...l));
  stmt.finalize();
});

db.close();