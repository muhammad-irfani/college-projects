const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const app = express();
const path = require('path');

const db = new sqlite3.Database('./database/houses.db');

app.use(express.static(path.join(__dirname, 'public')));

app.get('/api/houses', (req, res) => {
  let query = 'SELECT * FROM houses WHERE 1=1';
  const params = [];

  if (req.query.minPrice) {
    query += ' AND price >= ?';
    params.push(req.query.minPrice);
  }
  if (req.query.maxPrice) {
    query += ' AND price <= ?';
    params.push(req.query.maxPrice);
  }
  if (req.query.bedrooms) {
    query += ' AND bedrooms = ?';
    params.push(req.query.bedrooms);
  }
  if (req.query.type) {
    query += ' AND type = ?';
    params.push(req.query.type);
  }

  db.all(query, params, (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
